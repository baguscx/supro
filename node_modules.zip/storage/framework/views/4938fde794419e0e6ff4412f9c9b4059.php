            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl">
                <div
                  class="footer-container d-flex align-items-center justify-content-between py-3 flex-md-row flex-column">
                  <div class="text-body mb-2 mb-md-0">
                    ©
                    <script>
                      document.write(new Date().getFullYear());
                    </script>
                    , made with <span class="text-danger"><i class="tf-icons mdi mdi-heart"></i></span> by
                    <a href="#" target="_blank" class="footer-link fw-medium"
                      >Kurniawan</a
                    >
                  </div>
                  
                </div>
              </div>
            </footer>
<?php /**PATH C:\laragon\www\supro\resources\views/components/pages/footer.blade.php ENDPATH**/ ?>