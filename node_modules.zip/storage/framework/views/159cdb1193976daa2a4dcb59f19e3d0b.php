<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
    </style>
    <div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="py-3 mb-4">Pengguna</h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <button type="button" class="btn btn-primary mb-3" onclick="window.location.href = '<?php echo e(route('create.users')); ?>'">Tambah Pengguna</button>
                        <div class="table-responsive text-nowrap">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Alamat</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                        </i><span class="fw-medium"><?php echo e($user->name ?? ''); ?></span>
                                        </td>
                                        <td><?php echo e($user->email ?? ''); ?></td>
                                        <td>
                                            <?php echo e($user->roles->pluck('name')->implode(', ') ?? ''); ?>

                                        </td>
                                        <td><?php echo e($user->detail_users->address ?? ''); ?></td>
                                        <td style="display: flex; gap:5px;">
                                                <button style="border: none; margin-block: 10px; cursor: pointer; border-radius: 5px; display: flex; align-items: center; justify-content: center; background-color: #4CAF50; color: white;"
                                                        onmouseover="this.style.backgroundColor='#45a049';"
                                                        onmouseout="this.style.backgroundColor='#4CAF50';">
                                                    <a style="text-decoration: none; color: #fff;" href="<?php echo e(route('edit.users', $user->id ?? '')); ?>"><span class="fas fa-edit" style="width: 20px"></span> </a>
                                                </button>
                                            <form action="<?php echo e(route('delete.users', $user->id ?? '')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="id" value="<?php echo e($user->id ?? ''); ?>">
                                                <button onclick="return confirm('Anda yakin ingin menghapus pengguna ini?');" style="border: none; margin-block: 10px; cursor: pointer; border-radius: 5px; display: flex; align-items: center; justify-content: center; background-color: #f44336; color: white;"
                                                        onmouseover="this.style.backgroundColor='#e53935';"
                                                        onmouseout="this.style.backgroundColor='#f44336';">
                                                    <a style="text-decoration: none; color: #fff;" href=""><span class="fas fa-trash" style="width: 20px"></span> </a>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\supro\resources\views/admin/users/list.blade.php ENDPATH**/ ?>