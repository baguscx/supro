<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed layout-compact"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="<?php echo e(asset('/assets')); ?>"
  data-template="vertical-menu-template-free">
  <head>
    <?php if (isset($component)) { $__componentOriginalf839b35f7e2ac0692972a35f76b29ab9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf839b35f7e2ac0692972a35f76b29ab9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf839b35f7e2ac0692972a35f76b29ab9)): ?>
<?php $attributes = $__attributesOriginalf839b35f7e2ac0692972a35f76b29ab9; ?>
<?php unset($__attributesOriginalf839b35f7e2ac0692972a35f76b29ab9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf839b35f7e2ac0692972a35f76b29ab9)): ?>
<?php $component = $__componentOriginalf839b35f7e2ac0692972a35f76b29ab9; ?>
<?php unset($__componentOriginalf839b35f7e2ac0692972a35f76b29ab9); ?>
<?php endif; ?>
    <title><?php echo e($title ?? 'laravel'); ?></title>
  </head>

  <body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
        <?php if(Auth::user()->hasRole('admin')): ?>
            <?php if (isset($component)) { $__componentOriginal6702637fcda68559f293a0e6ab31b9f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6702637fcda68559f293a0e6ab31b9f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6702637fcda68559f293a0e6ab31b9f6)): ?>
<?php $attributes = $__attributesOriginal6702637fcda68559f293a0e6ab31b9f6; ?>
<?php unset($__attributesOriginal6702637fcda68559f293a0e6ab31b9f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6702637fcda68559f293a0e6ab31b9f6)): ?>
<?php $component = $__componentOriginal6702637fcda68559f293a0e6ab31b9f6; ?>
<?php unset($__componentOriginal6702637fcda68559f293a0e6ab31b9f6); ?>
<?php endif; ?>
        <?php elseif(Auth::user()->hasRole('staff')): ?>
            <?php if (isset($component)) { $__componentOriginal8a86b71af5b7b61214326195cb028ace = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a86b71af5b7b61214326195cb028ace = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.staff','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.staff'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a86b71af5b7b61214326195cb028ace)): ?>
<?php $attributes = $__attributesOriginal8a86b71af5b7b61214326195cb028ace; ?>
<?php unset($__attributesOriginal8a86b71af5b7b61214326195cb028ace); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a86b71af5b7b61214326195cb028ace)): ?>
<?php $component = $__componentOriginal8a86b71af5b7b61214326195cb028ace; ?>
<?php unset($__componentOriginal8a86b71af5b7b61214326195cb028ace); ?>
<?php endif; ?>
        <?php elseif(Auth::user()->hasRole('user')): ?>
            <?php if (isset($component)) { $__componentOriginal2e649052fc4c9ced05d3e0db52c846bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e649052fc4c9ced05d3e0db52c846bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.user','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e649052fc4c9ced05d3e0db52c846bc)): ?>
<?php $attributes = $__attributesOriginal2e649052fc4c9ced05d3e0db52c846bc; ?>
<?php unset($__attributesOriginal2e649052fc4c9ced05d3e0db52c846bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e649052fc4c9ced05d3e0db52c846bc)): ?>
<?php $component = $__componentOriginal2e649052fc4c9ced05d3e0db52c846bc; ?>
<?php unset($__componentOriginal2e649052fc4c9ced05d3e0db52c846bc); ?>
<?php endif; ?>
        <?php endif; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
            <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row gy-4">
                
                <?php echo e($slot); ?>

              </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php if (isset($component)) { $__componentOriginale1a5dc06883efde99c738294c04804ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1a5dc06883efde99c738294c04804ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $attributes = $__attributesOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__attributesOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1a5dc06883efde99c738294c04804ea)): ?>
<?php $component = $__componentOriginale1a5dc06883efde99c738294c04804ea; ?>
<?php unset($__componentOriginale1a5dc06883efde99c738294c04804ea); ?>
<?php endif; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <?php if (isset($component)) { $__componentOriginalb4f32c9018bd042434bbeb9dfe042086 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb4f32c9018bd042434bbeb9dfe042086 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb4f32c9018bd042434bbeb9dfe042086)): ?>
<?php $attributes = $__attributesOriginalb4f32c9018bd042434bbeb9dfe042086; ?>
<?php unset($__attributesOriginalb4f32c9018bd042434bbeb9dfe042086); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4f32c9018bd042434bbeb9dfe042086)): ?>
<?php $component = $__componentOriginalb4f32c9018bd042434bbeb9dfe042086; ?>
<?php unset($__componentOriginalb4f32c9018bd042434bbeb9dfe042086); ?>
<?php endif; ?>
  </body>
</html>
<?php /**PATH C:\laragon\www\supro\resources\views/layouts/app.blade.php ENDPATH**/ ?>