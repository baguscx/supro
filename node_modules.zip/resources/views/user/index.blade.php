<x-app-layout>
    <a href="{{route('create.proposal')}}">Buat</a>
</x-app-layout>
