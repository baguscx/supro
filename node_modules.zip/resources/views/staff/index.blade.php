<x-app-layout>
    staff
</x-app-layout>
