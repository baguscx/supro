<input {!! $attributes->merge(['class' => 'form-control', 'type' => $type ? '' : 'text']) !!} />
