<div <?php echo e($attributes); ?> style="display: none;" class="row mt-2 gy-4">
    <div class="col-md-12">
        <small>Substansi Proposal : <strong>Kelompok KHUSUS</strong></small>
            <div class="mt-3 form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="ringkasan_khusus" placeholder="Ringkasan"><?php echo e($proposal->ringkasan_khusus ?? ''); ?></textarea>
                <label class="ps-4">Ringkasan</label>
            </div>
    </div>

    <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="deskripsi_awal" placeholder="Deskripsi Awal Inovasi"><?php echo e($proposal->deskripsi_awal ?? ''); ?></textarea>
                <label class="ps-4">Deskripsi Awal Inovasi</label>
            </div>
    </div>

    <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="pembaruan" placeholder="Pembaruan / Peningkatan Inovasi"><?php echo e($proposal->pembaruan ?? ''); ?></textarea>
                <label class="ps-4">Pembaruan / Peningkatan Inovasi</label>
            </div>
    </div>

    <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="dampak" placeholder="Dampak"><?php echo e($proposal->dampak ?? ''); ?></textarea>
                <label class="ps-4">Dampak</label>
            </div>
    </div>

    <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="adaptabilitas_khusus" placeholder="Adaptabilitas"><?php echo e($proposal->adaptabilitas_khusus ?? ''); ?></textarea>
                <label class="ps-4">Adaptabilitas</label>
            </div>
    </div>

    <div class="col-md-12">
        <div class="form-floating form-floating-outline">
            <textarea class="form-control h-px-100" name="penguatan" placeholder="Penguatan Sumber Daya"><?php echo e($proposal->penguatan ?? ''); ?></textarea>
            <label class="ps-4">Penguatan Sumber Daya</label>
        </div>
    </div>

    <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="strategi_penguatan" placeholder="Strategi Penguatan Keberlanjutan"><?php echo e($proposal->strategi_penguatan ?? ''); ?></textarea>
                <label class="ps-4">Strategi Penguatan Keberlanjutan</label>
            </div>
    </div>

    
</div>
<?php /**PATH C:\laragon\www\supro\resources\views/components/kelompok/khusus.blade.php ENDPATH**/ ?>