<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
    </style>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard
     <?php $__env->endSlot(); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">Daftar Proposal Inovasi</h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body pt-3 mt-1">
                        <div class="table-responsive text-nowrap">
                            <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Judul Inovasi</th>
                                    <th>Kelompok</th>
                                    <th>Kategori</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($proposals->isEmpty()): ?>
                                <div class="alert alert-warning" role="alert">
                                    Tidak ada Proposal.
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="fw-medium" style="max-width: 200px; word-wrap: break-word; word-break: break-all; white-space: normal;"><?php echo e($proposal->judul_inovasi); ?></span>
                                    </td>
                                    <td><?php echo e($proposal->kelompok_inovasi); ?></td>
                                    <td><?php echo e($proposal->kategori_inovasi); ?></td>
                                    <td>
                                        <?php if($proposal->status == 'draft'): ?>
                                            <span class="badge rounded-pill bg-label-info me-1"><?php echo e($proposal->status); ?></span>
                                        <?php elseif($proposal->status == 'pending'): ?>
                                            <span class="badge rounded-pill bg-label-warning me-1"><?php echo e($proposal->status); ?></span>
                                        <?php elseif($proposal->status == 'completed'): ?>
                                            <span class="badge rounded-pill bg-label-success me-1"><?php echo e($proposal->status); ?></span>
                                        <?php endif; ?>
                                    </>
                                    <td style="display: flex;">
                                            <button style="border: none; margin: 10px; cursor: pointer; border-radius: 5px; display: flex; align-items: center; justify-content: center; background-color: #833bec; color: white;"
                                                    onmouseover="this.style.backgroundColor='#833bcf';"
                                                    onmouseout="this.style.backgroundColor='#833bec';">
                                                    <a style="text-decoration: none; color: #fff;" href="<?php echo e(route('show.proposal', $proposal->id)); ?>"><span class="fas fa-eye" style="width: 20px"></span></a>
                                            </button>
                                            
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\supro\resources\views/staff/list.blade.php ENDPATH**/ ?>