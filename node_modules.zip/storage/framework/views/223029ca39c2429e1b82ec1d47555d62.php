<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard
     <?php $__env->endSlot(); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">Proposal Inovasi</h4>

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body pt-2 mt-1">
                        <form id="formAccountSettings" method="POST" action="<?php echo e(route('store.proposal')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mt-2 gy-4">
                                <div class="col-md-12">
                                    <small>Isian Umum</small>
                                    <div class="mt-3 form-floating form-floating-outline">
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','placeholder' => 'Judul Inovasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','placeholder' => 'Judul Inovasi']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        <label for="judul_inovasi">Judul Inovasi</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating form-floating-outline">
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'waktu_implementasi','name' => 'waktu_implementasi','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'waktu_implementasi','name' => 'waktu_implementasi','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        <label for="waktu_implementasi">Waktu Implementasi</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating form-floating-outline">
                                        <select id="kelompok_inovasi" name="kelompok_inovasi" class="form-select form-select-lg" onchange="showCard(this.value)" >
                                            <option>----------------Kelompok Inovasi----------------</option>
                                            <option value="Kelompok Umum">Kelompok Umum</option>
                                            <option value="Kelompok Khusus">Kelompok Khusus</option>
                                        </select>
                                        <label for="kelompok_inovasi">Kelompok Inovasi</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating form-floating-outline">
                                        <select id="kategori_inovasi" name="kategori_inovasi" class="form-select form-select-lg">
                                            <option>----------------Kategori Inovasi----------------</option>
                                            <option value="Kesehatan">Kesehatan</option>
                                            <option value="Pendidikan">Pendidikan</option>
                                            <option value="Pertumbuhan ekonomi dan kesempatan kerja">Pertumbuhan ekonomi dan kesempatan kerja</option>
                                            <option value="Pengentasan kemiskinan">Pengentasan kemiskinan</option>
                                            <option value="Ketahanan pangan">Ketahanan pangan</option>
                                            <option value="Pemberdayaan masyarakat">Pemberdayaan masyarakat</option>
                                            <option value="Inklusi sosial">Inklusi sosial</option>
                                            <option value="Energi dan lingkungan hidup">Energi dan lingkungan hidup</option>
                                            <option value="Tata kelola pemerintahan">Tata kelola pemerintahan</option>
                                            <option value="Penegakan hukum">Penegakan hukum</option>
                                            <option value="Ketahanan bencana">Ketahanan bencana</option>
                                        </select>
                                        <label for="kategori_inovasi">Kelompok Inovasi</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating form-floating-outline">
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','placeholder' => 'Target SDGs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','placeholder' => 'Target SDGs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        <label for="target_sdgs">Target SDGs</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating form-floating-outline">
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','placeholder' => 'youtu.be/abcdefg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','placeholder' => 'youtu.be/abcdefg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        <label for="video_inovasi">Link Video Inovasi</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Surat Pernyataan Inovator</label>
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Surat Pernyataan Kesediaan Replikasi Inovasi</label>
                                        <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <hr class="m-0">
                            
                            <?php if (isset($component)) { $__componentOriginala6ce291d4f3350ff41bb3309e9feb7eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6ce291d4f3350ff41bb3309e9feb7eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.umum','data' => ['id' => 'kelompok_umum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.umum'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kelompok_umum']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6ce291d4f3350ff41bb3309e9feb7eb)): ?>
<?php $attributes = $__attributesOriginala6ce291d4f3350ff41bb3309e9feb7eb; ?>
<?php unset($__attributesOriginala6ce291d4f3350ff41bb3309e9feb7eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6ce291d4f3350ff41bb3309e9feb7eb)): ?>
<?php $component = $__componentOriginala6ce291d4f3350ff41bb3309e9feb7eb; ?>
<?php unset($__componentOriginala6ce291d4f3350ff41bb3309e9feb7eb); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal4d6681d39f42bdd23b92861a9ad62051 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d6681d39f42bdd23b92861a9ad62051 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.khusus','data' => ['id' => 'kelompok_khusus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.khusus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kelompok_khusus']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d6681d39f42bdd23b92861a9ad62051)): ?>
<?php $attributes = $__attributesOriginal4d6681d39f42bdd23b92861a9ad62051; ?>
<?php unset($__attributesOriginal4d6681d39f42bdd23b92861a9ad62051); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d6681d39f42bdd23b92861a9ad62051)): ?>
<?php $component = $__componentOriginal4d6681d39f42bdd23b92861a9ad62051; ?>
<?php unset($__componentOriginal4d6681d39f42bdd23b92861a9ad62051); ?>
<?php endif; ?>

                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary me-2">Save changes</button>
                                <button type="reset" class="btn btn-outline-secondary">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<script>
    function showCard(selectedValue) {
        // Semua card disembunyikan terlebih dahulu
        document.getElementById("kelompok_umum").style.display = "none";
        document.getElementById("kelompok_khusus").style.display = "none";

        // Tampilkan card sesuai dengan nilai yang dipilih
        if (selectedValue === "Kelompok Umum") {
            document.getElementById("kelompok_umum").style.display = "block";
        }
        else if (selectedValue === "Kelompok Khusus") {
            document.getElementById("kelompok_khusus").style.display = "block";
        }
    }
</script>
<?php /**PATH C:\laragon\www\supro\resources\views/user/create.blade.php ENDPATH**/ ?>