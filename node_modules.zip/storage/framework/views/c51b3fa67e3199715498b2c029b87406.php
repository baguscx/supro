    <div <?php echo e($attributes); ?> style="display: none;" class="row mt-2 gy-4">
        <div class="col-md-12">
            <small>Substansi Proposal : <strong>Kelompok UMUM</strong></small>
                <div class="mt-3 form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="ringkasan" placeholder="Ringkasan"><?php echo e($proposal->ringkasan ?? ''); ?></textarea>
                    <label class="ps-4">Ringkasan</label>
                </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="latar_belakang" placeholder="Latar Belakang & Tujuan"><?php echo e($proposal->latar_belakang ?? ''); ?></textarea>
                    <label class="ps-4">Latar Belakang & Tujuan</label>
                </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="kebaruan" placeholder="Kebaruan / Nilai Tambah"><?php echo e($proposal->kebaruan ?? ''); ?></textarea>
                    <label class="ps-4">Kebaruan / Nilai Tambah</label>
                </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="implementasi_inovasi" placeholder="Implementasi Inovasi"><?php echo e($proposal->implementasi_inovasi ?? ''); ?></textarea>
                    <label class="ps-4">Implementasi Inovasi</label>
                </div>
        </div>

        <div class="col-md-12">
            <div class="form-floating form-floating-outline">
                <textarea class="form-control h-px-100" name="signifikansi" placeholder="Signifikansi"><?php echo e($proposal->signifikansi ?? ''); ?></textarea>
                <label class="ps-4">Signifikansi</label>
            </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="adaptabilitas" placeholder="Adaptabilitas"><?php echo e($proposal->adaptabilitas ?? ''); ?></textarea>
                    <label class="ps-4">Adaptabilitas</label>
                </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="sumber_daya" placeholder="Sumber Daya"><?php echo e($proposal->sumber_daya ?? ''); ?></textarea>
                    <label class="ps-4">Sumber Daya</label>
                </div>
        </div>

        <div class="col-md-12">
                <div class="form-floating form-floating-outline">
                    <textarea class="form-control h-px-100" name="strategi_keberlanjutan" placeholder="Strategi Keberlanjutan"><?php echo e($proposal->strategi_keberlanjutan ?? ''); ?></textarea>
                    <label class="ps-4">Strategi Keberlanjutan</label>
                </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\supro\resources\views/components/kelompok/umum.blade.php ENDPATH**/ ?>