<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard
     <?php $__env->endSlot(); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-md-9">
                    <div class="card mb-4">
                        <div class="card-body pt-2 mt-1">
                            <iframe src="http://supro.test/cetak/<?php echo e($proposal->id); ?>" style="width:100%; height:600px;" frameborder="0"></iframe>
                        </div>
                    </div>
                </div>

                <?php if($proposal->status == 'pending' && Auth::user()->hasRole('staff')): ?>
                <div class="col-md-3">
                    <div class="card mb-4">
                        <div class="card-body pt-2 mt-1">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <button data-toggle="modal" data-target="#passwordModal" class="btn btn-primary btn-block mb-2">Tanda Tangani</button>
                                    <button onclick="showCard()" name="revisi" id="revisi" class="btn btn-info btn-block mb-2">Revisi</button>
                                    <form style="display: none;" name="revisi-form" id="revisi-form" action="<?php echo e(route('revisi.proposal', $proposal->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <textarea name="note" class="form-control mb-1" id="noteInput" cols="30" rows="10" placeholder="Masukkan Catatan"></textarea>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-sm btn-success mb-2" >Kirim</button>
                                        </div>
                                    </form>
                                    <button data-toggle="modal" data-target="#noteModal" class="btn btn-danger btn-block mb-2">Tolak</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                
                <div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="passwordModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="passwordModalLabel">Masukkan Password</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('ttd.proposal', $proposal->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="passwordInput">Password</label>
                                        <input name="ttd" type="password" class="form-control" id="passwordInput" placeholder="Masukkan password">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Konfirmasi</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
                

                
                <div class="modal fade" id="noteModal" tabindex="-1" role="dialog" aria-labelledby="passwordModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="passwordModalLabel">Catatan Tolak</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('tolak.proposal', $proposal->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <textarea name="note" class="form-control" id="noteInput" cols="30" rows="10" placeholder="Masukkan Catatan"></textarea>                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Kirim</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
                

            </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    function showCard() {
        var revisiForm = document.getElementById("revisi-form");
        var revisiButton = document.getElementById("revisi");

        // Toggle the display of the revisi-form
        revisiForm.style.display = revisiForm.style.display === "none" ? "block" : "none";

        // Change the text of the revisi button based on the form's display
        revisiButton.innerText = revisiForm.style.display === "none" ? "Revisi" : "Batal";
    }
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\supro\resources\views/staff/show.blade.php ENDPATH**/ ?>