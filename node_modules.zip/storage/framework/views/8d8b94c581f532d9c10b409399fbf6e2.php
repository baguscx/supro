<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard
     <?php $__env->endSlot(); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4">Proposal Inovasi</h4>

        <?php if($proposal->status == "draft" || $proposal->status == "revision"): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-body pt-2 mt-1">
                            <form id="formAccountSettings" method="POST" action="<?php echo e(route('update.proposal', $proposal->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row mt-2 gy-4">
                                    <div class="col-md-12">
                                        <small>Isian Umum</small>
                                        <div class="mt-3 form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','value' => ''.e($proposal->judul_inovasi).'','placeholder' => 'Judul Inovasi','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','value' => ''.e($proposal->judul_inovasi).'','placeholder' => 'Judul Inovasi','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="judul_inovasi">Judul Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'waktu_implementasi','name' => 'waktu_implementasi','value' => ''.e($proposal->waktu_implementasi).'','type' => 'date','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'waktu_implementasi','name' => 'waktu_implementasi','value' => ''.e($proposal->waktu_implementasi).'','type' => 'date','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="waktu_implementasi">Waktu Implementasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <select id="kelompok_inovasi" name="kelompok_inovasi" class="form-select form-select-lg" disabled>
                                                <option>----------------Kelompok Inovasi----------------</option>
                                                <option value="Kelompok Umum" <?php echo e($proposal->kelompok_inovasi == "Kelompok Umum" ? 'selected' : ''); ?>>Kelompok Umum</option>
                                                <option value="Kelompok Khusus" <?php echo e($proposal->kelompok_inovasi == "Kelompok Khusus" ? 'selected' : ''); ?>>Kelompok Khusus</option>
                                            </select>
                                            <label for="kelompok_inovasi">Kelompok Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <select id="kategori_inovasi" name="kategori_inovasi" class="form-select form-select-lg" disabled>
                                                <option>----------------Kategori Inovasi----------------</option>
                                                <option value="Kesehatan" <?php echo e($proposal->kategori_inovasi == "Kesehatan" ? 'selected' : ''); ?>>Kesehatan</option>
                                                <option value="Pendidikan" <?php echo e($proposal->kategori_inovasi == "Pendidikan" ? 'selected' : ''); ?>>Pendidikan</option>
                                                <option value="Pertumbuhan ekonomi dan kesempatan kerja" <?php echo e($proposal->kategori_inovasi == "Pertumbuhan ekonomi dan kesempatan kerjaa" ? 'selected' : ''); ?>>Pertumbuhan ekonomi dan kesempatan kerja</option>
                                                <option value="Pengentasan kemiskinan" <?php echo e($proposal->kategori_inovasi == "Pengentasan kemiskinan" ? 'selected' : ''); ?>>Pengentasan kemiskinan</option>
                                                <option value="Ketahanan pangan" <?php echo e($proposal->kategori_inovasi == "Ketahanan pangan" ? 'selected' : ''); ?>>Ketahanan pangan</option>
                                                <option value="Pemberdayaan masyarakat" <?php echo e($proposal->kategori_inovasi == "Pemberdayaan masyarakat" ? 'selected' : ''); ?>>Pemberdayaan masyarakat</option>
                                                <option value="Inklusi sosial" <?php echo e($proposal->kategori_inovasi == "Inklusi sosial" ? 'selected' : ''); ?>>Inklusi sosial</option>
                                                <option value="Energi dan lingkungan hidup" <?php echo e($proposal->kategori_inovasi == "Energi dan lingkungan hidup" ? 'selected' : ''); ?>>Energi dan lingkungan hidup</option>
                                                <option value="Tata kelola pemerintahan" <?php echo e($proposal->kategori_inovasi == "Tata kelola pemerintahan" ? 'selected' : ''); ?>>Tata kelola pemerintahan</option>
                                                <option value="Penegakan hukum" <?php echo e($proposal->kategori_inovasi == "Penegakan hukum" ? 'selected' : ''); ?>>Penegakan hukum</option>
                                                <option value="Ketahanan bencana" <?php echo e($proposal->kategori_inovasi == "Ketahanan bencana" ? 'selected' : ''); ?>>Ketahanan bencana</option>
                                            </select>
                                            <label for="kategori_inovasi">Kelompok Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','value' => ''.e($proposal->target_sdgs).'','placeholder' => 'Target SDGs','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','value' => ''.e($proposal->target_sdgs).'','placeholder' => 'Target SDGs','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="target_sdgs">Target SDGs</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','value' => ''.e($proposal->video_inovasi).'','placeholder' => 'youtu.be/abcdefg','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','value' => ''.e($proposal->video_inovasi).'','placeholder' => 'youtu.be/abcdefg','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="video_inovasi">Link Video Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Surat Pernyataan Inovator [<a href="<?php echo e(route('dinovator', $proposal->id)); ?>">Download File</a>]</label>
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Surat Pernyataan Kesediaan Replikasi Inovasi [<a href="<?php echo e(route('dinovasi', $proposal->id)); ?>">Download File</a>]</label>
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <hr class="m-0">
                                
                                <?php if($proposal->kelompok_inovasi == "Kelompok Umum"): ?>
                                    <?php if (isset($component)) { $__componentOriginalc83a752da87071eaa7abc5299dedcaf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a752da87071eaa7abc5299dedcaf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.view_umum','data' => ['style' => 'display: block','id' => 'kelompok_umum','proposal' => $proposal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.view_umum'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'display: block','id' => 'kelompok_umum','proposal' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($proposal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a752da87071eaa7abc5299dedcaf2)): ?>
<?php $attributes = $__attributesOriginalc83a752da87071eaa7abc5299dedcaf2; ?>
<?php unset($__attributesOriginalc83a752da87071eaa7abc5299dedcaf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a752da87071eaa7abc5299dedcaf2)): ?>
<?php $component = $__componentOriginalc83a752da87071eaa7abc5299dedcaf2; ?>
<?php unset($__componentOriginalc83a752da87071eaa7abc5299dedcaf2); ?>
<?php endif; ?>
                                <?php elseif($proposal->kelompok_inovasi == "Kelompok Khusus"): ?>
                                    <?php if (isset($component)) { $__componentOriginal76ec597fc9db9a5144addabc430fa133 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76ec597fc9db9a5144addabc430fa133 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.view_khusus','data' => ['style' => 'display: block','id' => 'kelompok_khusus','proposal' => $proposal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.view_khusus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'display: block','id' => 'kelompok_khusus','proposal' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($proposal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76ec597fc9db9a5144addabc430fa133)): ?>
<?php $attributes = $__attributesOriginal76ec597fc9db9a5144addabc430fa133; ?>
<?php unset($__attributesOriginal76ec597fc9db9a5144addabc430fa133); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76ec597fc9db9a5144addabc430fa133)): ?>
<?php $component = $__componentOriginal76ec597fc9db9a5144addabc430fa133; ?>
<?php unset($__componentOriginal76ec597fc9db9a5144addabc430fa133); ?>
<?php endif; ?>
                                <?php else: ?>
                                    Tidak ada kelompok
                                <?php endif; ?>

                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary me-2">Save changes</button>
                                    <button type="reset" class="btn btn-outline-secondary">Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif($proposal->status == "pending" || $proposal->status == "completed"): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-body pt-2 mt-1">
                            <form id="formAccountSettings" method="POST" action="<?php echo e(route('update.proposal', $proposal->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row mt-2 gy-4">
                                    <div class="col-md-12">
                                        <small>Isian Umum</small>
                                        <div class="mt-3 form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','value' => ''.e($proposal->judul_inovasi).'','placeholder' => 'Judul Inovasi','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'judul_inovasi','name' => 'judul_inovasi','type' => 'text','value' => ''.e($proposal->judul_inovasi).'','placeholder' => 'Judul Inovasi','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="judul_inovasi">Judul Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'waktu_implementasi','name' => 'waktu_implementasi','value' => ''.e($proposal->waktu_implementasi).'','type' => 'date','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'waktu_implementasi','name' => 'waktu_implementasi','value' => ''.e($proposal->waktu_implementasi).'','type' => 'date','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="waktu_implementasi">Waktu Implementasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <select id="kelompok_inovasi" name="kelompok_inovasi" class="form-select form-select-lg" disabled>
                                                <option>----------------Kelompok Inovasi----------------</option>
                                                <option value="Kelompok Umum" <?php echo e($proposal->kelompok_inovasi == "Kelompok Umum" ? 'selected' : ''); ?>>Kelompok Umum</option>
                                                <option value="Kelompok Khusus" <?php echo e($proposal->kelompok_inovasi == "Kelompok Khusus" ? 'selected' : ''); ?>>Kelompok Khusus</option>
                                            </select>
                                            <label for="kelompok_inovasi">Kelompok Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <select id="kategori_inovasi" name="kategori_inovasi" class="form-select form-select-lg" disabled>
                                                <option>----------------Kategori Inovasi----------------</option>
                                                <option value="Kesehatan" <?php echo e($proposal->kategori_inovasi == "Kesehatan" ? 'selected' : ''); ?>>Kesehatan</option>
                                                <option value="Pendidikan" <?php echo e($proposal->kategori_inovasi == "Pendidikan" ? 'selected' : ''); ?>>Pendidikan</option>
                                                <option value="Pertumbuhan ekonomi dan kesempatan kerja" <?php echo e($proposal->kategori_inovasi == "Pertumbuhan ekonomi dan kesempatan kerjaa" ? 'selected' : ''); ?>>Pertumbuhan ekonomi dan kesempatan kerja</option>
                                                <option value="Pengentasan kemiskinan" <?php echo e($proposal->kategori_inovasi == "Pengentasan kemiskinan" ? 'selected' : ''); ?>>Pengentasan kemiskinan</option>
                                                <option value="Ketahanan pangan" <?php echo e($proposal->kategori_inovasi == "Ketahanan pangan" ? 'selected' : ''); ?>>Ketahanan pangan</option>
                                                <option value="Pemberdayaan masyarakat" <?php echo e($proposal->kategori_inovasi == "Pemberdayaan masyarakat" ? 'selected' : ''); ?>>Pemberdayaan masyarakat</option>
                                                <option value="Inklusi sosial" <?php echo e($proposal->kategori_inovasi == "Inklusi sosial" ? 'selected' : ''); ?>>Inklusi sosial</option>
                                                <option value="Energi dan lingkungan hidup" <?php echo e($proposal->kategori_inovasi == "Energi dan lingkungan hidup" ? 'selected' : ''); ?>>Energi dan lingkungan hidup</option>
                                                <option value="Tata kelola pemerintahan" <?php echo e($proposal->kategori_inovasi == "Tata kelola pemerintahan" ? 'selected' : ''); ?>>Tata kelola pemerintahan</option>
                                                <option value="Penegakan hukum" <?php echo e($proposal->kategori_inovasi == "Penegakan hukum" ? 'selected' : ''); ?>>Penegakan hukum</option>
                                                <option value="Ketahanan bencana" <?php echo e($proposal->kategori_inovasi == "Ketahanan bencana" ? 'selected' : ''); ?>>Ketahanan bencana</option>
                                            </select>
                                            <label for="kategori_inovasi">Kelompok Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','value' => ''.e($proposal->target_sdgs).'','placeholder' => 'Target SDGs','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'target_sdgs','name' => 'target_sdgs','type' => 'text','value' => ''.e($proposal->target_sdgs).'','placeholder' => 'Target SDGs','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="target_sdgs">Target SDGs</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating form-floating-outline">
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','value' => ''.e($proposal->video_inovasi).'','placeholder' => 'youtu.be/abcdefg','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'video_inovasi','name' => 'video_inovasi','type' => 'text','value' => ''.e($proposal->video_inovasi).'','placeholder' => 'youtu.be/abcdefg','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                            <label for="video_inovasi">Link Video Inovasi</label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Surat Pernyataan Inovator [<a href="<?php echo e(route('dinovator', $proposal->id)); ?>">Download File</a>]</label>
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_inovator','name' => 'sp_inovator','type' => 'file','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Surat Pernyataan Kesediaan Replikasi Inovasi [<a href="<?php echo e(route('dinovasi', $proposal->id)); ?>">Download File</a>]</label>
                                            <?php if (isset($component)) { $__componentOriginal3792377c59784ef8855716949b382c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3792377c59784ef8855716949b382c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.text-input','data' => ['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sp_replikasi','name' => 'sp_replikasi','type' => 'file','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $attributes = $__attributesOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__attributesOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3792377c59784ef8855716949b382c5d)): ?>
<?php $component = $__componentOriginal3792377c59784ef8855716949b382c5d; ?>
<?php unset($__componentOriginal3792377c59784ef8855716949b382c5d); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <hr class="m-0">
                                
                                <?php if($proposal->kelompok_inovasi == "Kelompok Umum"): ?>
                                    <?php if (isset($component)) { $__componentOriginalc83a752da87071eaa7abc5299dedcaf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a752da87071eaa7abc5299dedcaf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.view_umum','data' => ['style' => 'display: block','id' => 'kelompok_umum','proposal' => $proposal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.view_umum'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'display: block','id' => 'kelompok_umum','proposal' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($proposal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a752da87071eaa7abc5299dedcaf2)): ?>
<?php $attributes = $__attributesOriginalc83a752da87071eaa7abc5299dedcaf2; ?>
<?php unset($__attributesOriginalc83a752da87071eaa7abc5299dedcaf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a752da87071eaa7abc5299dedcaf2)): ?>
<?php $component = $__componentOriginalc83a752da87071eaa7abc5299dedcaf2; ?>
<?php unset($__componentOriginalc83a752da87071eaa7abc5299dedcaf2); ?>
<?php endif; ?>
                                <?php elseif($proposal->kelompok_inovasi == "Kelompok Khusus"): ?>
                                    <?php if (isset($component)) { $__componentOriginal76ec597fc9db9a5144addabc430fa133 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76ec597fc9db9a5144addabc430fa133 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kelompok.view_khusus','data' => ['style' => 'display: block','id' => 'kelompok_khusus','proposal' => $proposal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kelompok.view_khusus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'display: block','id' => 'kelompok_khusus','proposal' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($proposal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76ec597fc9db9a5144addabc430fa133)): ?>
<?php $attributes = $__attributesOriginal76ec597fc9db9a5144addabc430fa133; ?>
<?php unset($__attributesOriginal76ec597fc9db9a5144addabc430fa133); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76ec597fc9db9a5144addabc430fa133)): ?>
<?php $component = $__componentOriginal76ec597fc9db9a5144addabc430fa133; ?>
<?php unset($__componentOriginal76ec597fc9db9a5144addabc430fa133); ?>
<?php endif; ?>
                                <?php else: ?>
                                    Tidak ada kelompok
                                <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\supro\resources\views/user/edit.blade.php ENDPATH**/ ?>